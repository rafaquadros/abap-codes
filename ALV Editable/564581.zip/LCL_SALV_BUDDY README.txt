Hi everybody!

I've developed a local class capable of setting any field of a CL_SALV_TABLE object ready for input.

I named it LCL_SALV_BUDDY.

To use it:

1) Copy and paste the ABAP source code contained in TXT file LCL_SALV_BUDDY CLASS.TXT into your program or
   into a separate INCLUDE file and include it in your program.

2) In your program containing the CL_SALV_TABLE object:

   a) if you want to make ALL table fields ready for input,
      insert the following single line of code:

      lcl_salv_buddy=>set_editable( i_salv_table = YOUR_CL_SALV_TABLE_OBJECT_GOES_HERE ).

   b) if you want to make ALL table fields NOT ready for input,
      insert the following single line of code:

      lcl_salv_buddy=>set_editable( i_salv_table = YOUR_CL_SALV_TABLE_OBJECT_GOES_HERE
                                    i_editable   = abap_false ).

   c) if you want to make specific, individual table fields ready for input,
      insert the following single line of code for each table field you want to set ready for input:

      lcl_salv_buddy=>set_editable( i_fieldname  = 'YOUR_TABLE_FIELD_NAME_GOES_HERE'
                                    i_salv_table = YOUR_CL_SALV_TABLE_OBJECT_GOES_HERE ).
 
   d) if you want to make specific, individual table fields NOT ready for input,
      insert the following single line of code for each table field you want to set NOT ready for input:

      lcl_salv_buddy=>set_editable( i_fieldname  = 'YOUR_TABLE_FIELD_NAME_GOES_HERE'
                                    i_salv_table = YOUR_CL_SALV_TABLE_OBJECT_GOES_HERE
                                    i_editable   = abap_false ).

   NOTE: Setting the whole table ready for input always prevails over setting individual fields.
         So, if you have set the whole table ready for input as described on item a),
         you MUST set the whole table back to NOT ready for input, as described on item b), otherwise
         enabling and disabling individual tables fields for input, as described on items c) and d), won't work!
         Instead, the table will always have all its fields enabled for input...


   ...and where do I insert the code described on items 2a), 2b), 2c) and 2d) above?

      ONE OPTION - Your CL_SALV_TABLE object lives in a container, i.e., it's NOT fullscreen:

         Right after the point you call the DISPLAY method of the SALV object (YES, you read it right: AFTER the
         call to the DISPLAY method!), most likely in the PBO event of the screen holding the container.

      OTHER OPTION - You don't use a container for your CL_SAL_TABLE object, i.e., it's fullscreen:

         In this case, calling method SET_EDITABLE right after the SALV object display method won't work because
         the control won't exist anymore. When in fullscreen mode, the CL_SALV_TABLE display method
         immediately shows the ALV. Thus, you'll need a point where the ALV is still active, such as the events
         ADDED_FUNCTION or DOUBLE_CLICK.

         See file LCL_SALV_BUDDY EXAMPLE.TXT for a working example with a CL_SALV_TABLE object displayed fullscreen.


If you need FIELD VALIDATION or any other functionality available on class CL_GUI_ALV_GRID but not
exposed by class CL_SALV_TABLE, you'll have to call method GET_CONTROL to obtain the
underlying CL_GUI_ALV_GRID control that every CL_SALV_TABLE object has and
interact with it directly as you would normally do. This is exactly what method SET_EDITABLE does, by the way.

VERY IMPORTANT: Don't be lazy and take a look at the source code for class LCL_SALV_BUDDY to get to know the other
                functionalities available. You'll be surprised how simple it actually is.
