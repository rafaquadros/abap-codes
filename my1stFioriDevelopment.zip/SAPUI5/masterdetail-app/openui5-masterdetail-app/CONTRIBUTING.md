# Contributing to openui5-masterdetail-app

In general the contributing guidelines of OpenUI5 also apply to this project. They can be found here:  
https://github.com/SAP/openui5/blob/master/CONTRIBUTING.md

The code base of this repository is mirrored from the openui5 repository. 
Please create issues and pull requests there:
https://github.com/SAP/openui5